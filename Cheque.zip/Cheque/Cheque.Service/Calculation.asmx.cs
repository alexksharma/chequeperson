﻿#region History
/*
 * Created By   :   Surendra Sharma
 * Created Date :   July-30-2017
 * Description  :   Code file for API to receive the request from clients and return the result.
 * 
 * ************************************** Modification History ***********************************
 * Modified By               Modified Date         Reason
 * ***********************************************************************************************
 * <Name>                     <Date>                <Description>
 * ***********************************************************************************************
 * */
#endregion

#region Namespaces
using Cheque.CommonLibrary;
using System.Web.Services;
#endregion

namespace Cheque.Service
{
    /// <summary>
    /// Summary description for Calculation
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Calculation : System.Web.Services.WebService
    {
        /// <summary>
        /// Web Method to receive the request from clients and return the result.
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        [WebMethod]
        public string ConvertNumberToWord(decimal amount)
        {
            string result = "";
            if (amount < 0 || amount > System.Convert.ToDecimal(999999999999.99))
            {
                result = "Invalid Amount";
            }
            else
            {
                result = CurrencyUtility.NumberToCurrencyText(amount);
            }

            return result;
        }
    }
}

