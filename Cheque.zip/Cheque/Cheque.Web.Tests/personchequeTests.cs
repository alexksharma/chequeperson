﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Cheque.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cheque.Web.Tests
{
    [TestClass()]
    public class personchequeTests
    {
        [TestMethod()]
        public void IsValidDataTest()
        {
            string message = string.Empty;

            bool result = personcheque.IsValidData("Test", "-234", out message);
            Assert.IsFalse(result, "invalid Data for -ve number. " + message);

            result = personcheque.IsValidData("Test", "234", out message);
            Assert.IsTrue(result, "Valid Data. " + message);

            result = personcheque.IsValidData("", "234", out message);
            Assert.IsFalse(result, "invalid Data for empty name. " + message);


        }
    }
}