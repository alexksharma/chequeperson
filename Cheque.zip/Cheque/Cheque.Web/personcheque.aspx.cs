﻿#region History
/*
 * Created By   :   Surendra Sharma
 * Created Date :   July-30-2017
 * Description  :   Code file for Person Cheque web page which get name and amount from user and display entered name and amount in words.
 * 
 * ************************************** Modification History ***********************************
 * Modified By               Modified Date         Reason
 * ***********************************************************************************************
 * <Name>                     <Date>                <Description>
 * ***********************************************************************************************
 * */
#endregion

#region Namespaces
using System;
#endregion

namespace Cheque.Web
{
    /// <summary>
    /// Class for person cheque
    /// </summary>
    public partial class personcheque : System.Web.UI.Page
    {
        #region Events
        /// <summary>
        /// Page Load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Print Output Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string message = string.Empty;

            if (IsValidData(txtName.Text.Trim(), txtAmount.Text.Trim(), out message))
            {
                try
                {
                    PrintOutput();
                }
                catch (Exception ex)
                {
                    message += " <br> " + ex.Message;
                    ClearData(message);
                }
            }
            else
            {
                ClearData(message);
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Clear controls data
        /// </summary>
        /// <param name="message"></param>
        private void ClearData(string message)
        {
            lblError.Text = message;
            lblOutputName.Text = string.Empty;
            lblOutputAmount.Text = string.Empty;
        }

        /// <summary>
        /// Show result to page
        /// </summary>
        private void PrintOutput()
        {
            lblOutputName.Text = txtName.Text.Trim();
            string error = string.Empty;
            lblOutputAmount.Text = GetNumberInWords(txtAmount.Text.Trim(), out error);
            lblError.Text = error;
        }

        /// <summary>
        /// Get number in words format
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="error"></param>
        /// <returns></returns>
        private string GetNumberInWords(string amount, out string error)
        {
            string words = string.Empty;
            decimal result = 0;
            error = string.Empty;

            if (decimal.TryParse(amount, out result))
            {
                ChequeService.Calculation calculation = new ChequeService.Calculation();
                words = calculation.ConvertNumberToWord(result);
            }
            else
            {
                error = "Please enter valid amount.";
            }
            return words;
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Validate data
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool IsValidData(string name, string amount, out string message)
        {
            bool result = true;
            decimal currency = 0;
            message = string.Empty;

            if (string.IsNullOrEmpty(name))
            {
                message = "Name is mandatory.";
                result = false;
            }
            else if (string.IsNullOrEmpty(amount))
            {
                message = "Amount is mandatory.";
                result = false;
            }
            else if (!decimal.TryParse(amount, out currency) || currency < 0 || currency > Convert.ToDecimal(999999999999.99))
            {
                message = "Amount is not in valid format.";
                result = false;
            }

            return result;
        }
        #endregion
    }
}