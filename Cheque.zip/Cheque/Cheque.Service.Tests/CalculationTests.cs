﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Cheque.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cheque.Service.Tests
{
    [TestClass()]
    public class CalculationTests
    {
        [TestMethod()]
        public void ConvertNumberToWordTest()
        {
            ChequeWebService.Calculation calculation = new ChequeWebService.Calculation();
            string result = calculation.ConvertNumberToWord(10);
            Assert.AreEqual("TEN DOLLARS", result, "Result is equal");
            //cal.ConvertNumberToWord(678);

            result = calculation.ConvertNumberToWord(Convert.ToDecimal(10.10));
            Assert.AreEqual("TEN DOLLARS AND TEN CENTS", result, "Result is same");

            result = calculation.ConvertNumberToWord(0);
            Assert.AreNotEqual(result, null);

            result = calculation.ConvertNumberToWord(-2);
            Assert.AreEqual(result, "Invalid Amount", "Result is blank for -2");
        }
    }
}