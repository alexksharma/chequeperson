﻿#region History
/*
 * Created By   :   Surendra Sharma
 * Created Date :   July-30-2017
 * Description  :   Code file to convert currency amount to words.
 * 
 * ************************************** Modification History ***********************************
 * Modified By               Modified Date         Reason
 * ***********************************************************************************************
 * <Name>                     <Date>                <Description>
 * ***********************************************************************************************
 * */
#endregion

#region Namespaces
using System.Text;
#endregion

namespace Cheque.CommonLibrary
{
    /// <summary>
    /// Used for currency operations
    /// </summary>
    public class CurrencyUtility
    {
        #region Public Methods
        /// <summary>
        /// Convert decimal number to words
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static string NumberToCurrencyText(decimal number)
        {
            if (number < 0 || number > System.Convert.ToDecimal(999999999999.99))
            {
                return "Invalid Amount";
            }

            // Round the value just in case the decimal value is longer than two digits
            number = decimal.Round(number, 2);

            string wordNumber = string.Empty;

            // Divide the number into the whole and fractional part strings
            string[] arrNumber = number.ToString().Split('.');

            // Get the whole number text
            long wholePart = long.Parse(arrNumber[0]);
            string strWholePart = NumberToText(wholePart);

            // For amounts of zero dollars show 'No Dollars...' instead of 'Zero Dollars...'
            if (wholePart > 0)
            {
                wordNumber = (wholePart == 0 ? "No " : strWholePart) + (wholePart == 1 ? " Dollar " : " Dollars ");
            }

            // If the array has more than one element then there is a fractional part otherwise there isn't
            // just add 'No Cents' to the end
            if (arrNumber.Length > 1)
            {
                wordNumber = wordNumber.Trim();
                // If the length of the fractional element is only 1, add a 0 so that the text returned isn't,
                // 'One', 'Two', etc but 'Ten', 'Twenty', etc.
                long fractionPart = long.Parse((arrNumber[1].Length == 1 ? arrNumber[1] + "0" : arrNumber[1]));
                string strFarctionPart = NumberToText(fractionPart);

                if (fractionPart > 0)
                {
                    if(!string.IsNullOrEmpty(wordNumber))
                    {
                        wordNumber += " and ";
                    }

                    wordNumber += (fractionPart == 0 ? " No " : strFarctionPart) + (fractionPart == 1 ? " Cent" : " Cents");
                }
            }
            //else
            //    wordNumber += "No Cents";

            return wordNumber.ToUpper().Trim();
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Convert long to words
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        private static string NumberToText(long number)
        {
            StringBuilder wordNumber = new StringBuilder();

            string[] powers = new string[] { "Thousand ", "Million ", "Billion " };
            string[] tens = new string[] { "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };
            string[] ones = new string[] { "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                                       "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };

            if (number == 0) { return "Zero"; }
            if (number < 0)
            {
                wordNumber.Append("Negative ");
                number = -number;
            }

            long[] groupedNumber = new long[] { 0, 0, 0, 0 };
            int groupIndex = 0;

            while (number > 0)
            {
                groupedNumber[groupIndex++] = number % 1000;
                number /= 1000;
            }

            for (int counter = 3; counter >= 0; counter--)
            {
                long group = groupedNumber[counter];

                if (group >= 100)
                {
                    wordNumber.Append(ones[group / 100 - 1] + " Hundred ");
                    group %= 100;

                    if (group == 0 && counter > 0)
                        wordNumber.Append(powers[counter - 1]);
                }

                if (group >= 20)
                {
                    if ((group % 10) != 0)
                    {
                        if(wordNumber.Length > 0)
                        {
                            wordNumber.Append(" And ");
                        }
                        wordNumber.Append(tens[group / 10 - 2] + " " + ones[group % 10 - 1] + " ");
                    }
                    else
                        wordNumber.Append(tens[group / 10 - 2] + " ");
                }
                else if (group > 0)
                    wordNumber.Append(ones[group - 1] + " ");

                if (group != 0 && counter > 0)
                    wordNumber.Append(powers[counter - 1]);
            }

            return wordNumber.ToString().Trim();
        }
        #endregion
    }
}
