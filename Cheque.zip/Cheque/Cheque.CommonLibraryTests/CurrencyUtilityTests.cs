﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Cheque.CommonLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cheque.CommonLibrary.Tests
{
    [TestClass()]
    public class CurrencyUtilityTests
    {
        [TestMethod()]
        public void NumberToCurrencyTextTest()
        {
            string result = CurrencyUtility.NumberToCurrencyText(10);
            Assert.AreEqual("TEN DOLLARS", result, "Result is equal");
            //cal.ConvertNumberToWord(678);

            result = CurrencyUtility.NumberToCurrencyText(Convert.ToDecimal(10.10));
            Assert.AreEqual("TEN DOLLARS AND TEN CENTS", result, "Result is same");

            result = CurrencyUtility.NumberToCurrencyText(0);
            Assert.AreNotEqual(result, null);

            result = CurrencyUtility.NumberToCurrencyText(-2);
            Assert.AreEqual(result, "Invalid Amount", "Result is invalid data message.");
        }
    }
}